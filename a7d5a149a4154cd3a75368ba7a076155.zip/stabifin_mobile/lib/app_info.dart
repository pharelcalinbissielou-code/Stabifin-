class AppInfo {
  static const String appName = 'StabiFin';
  static const String author = 'BISSIELOU pharel calin';
  static const String owner = 'BISSIELOU pharel calin';
  static const String nationality = 'Gabonaise';
  static const String rights = 'Tous droits réservés à BISSIELOU pharel calin.';
}
